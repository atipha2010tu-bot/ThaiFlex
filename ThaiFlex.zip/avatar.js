/* ThaiFlex — โปรไฟล์ & ระบบสร้างอวาตาร์ */
let PF=(ME&&ME.pf)||{};
const AVD={
sk:['#fbe3cf','#f6d5b8','#efc29b','#e5ae82','#d79a6a','#c88556','#b0703f','#955a31','#7a4526','#5f331c','#f4d0c6','#e8c6a0'],
hc:['#1d1612','#3b2a20','#5b3b26','#7a4a2a','#8f3f24','#c0602a','#e3b865','#efe3c0','#a9a9a6','#e9e9e6','#3d6fc9','#2faaa0','#e56fa4','#8a5acb','#c53a3a','#58a74a'],
ic:['#2b1b14','#6a3f22','#8a6a2a','#3f8f5a','#3f78c4','#7d8a96','#8a5acb','#c9892a'],
tc:['#e0954f','#6aa8d8','#7fb35a','#d6628a','#8a79c9','#f0c75a','#d9503f','#3fa89b','#33466e','#f7f6f0','#2f2f33','#9a9aa0','#efe2c1','#8e2f3f','#8a8f3a','#2e4a7d'],
bg:['#fde7c8','#d8ecf8','#e0f0d2','#fbd9e5','#e6e0f6','#fff1c4','#cdeee6','#ffd9c7','#d9e4ff','#eadcc4','#f6d3ee','#d3f0ff','#e9f5b8','#ffe0e0','#c9d6c0','#f0e6ff','#bfe3d0','#ffd48a']};
const AVN={fs:4,ex:7,po:4,hs:28,ey:12,eb:8,no:4,mo:10,fh:7,ts:22,tp:5,ht:12,gl:8,er:6,nk:6,bp:8};
const AVDEF={sk:3,fs:1,ex:0,po:0,hs:1,hc:1,ey:0,ic:0,eb:0,no:0,mo:0,fh:0,ts:0,tc:0,tp:0,ht:0,hl:0,gl:0,er:0,nk:0,bg:0,bp:0};
const AVP=[{sk:3,hs:1,hc:0,ey:0,mo:0,ts:0,tc:0,bg:0},{sk:2,hs:15,hc:0,ey:5,eb:2,mo:1,ts:1,tc:1,bg:1,po:1,er:1},{sk:4,hs:9,hc:0,ey:1,mo:2,ts:4,tc:2,bg:2,ex:1},{sk:6,hs:8,hc:0,ey:0,eb:1,mo:0,ts:5,tc:3,bg:3,er:2},{sk:3,hs:4,hc:8,ey:1,eb:0,mo:1,gl:1,ts:17,tc:4,bg:4,fh:1,po:1},{sk:3,hs:16,hc:11,ey:0,mo:0,ts:0,tc:5,bg:5,nk:5,ex:4},{sk:1,hs:21,hc:12,ey:4,mo:0,ts:3,tc:7,bg:6,ht:0,ex:2},{sk:5,hs:2,hc:1,ey:11,eb:4,mo:4,ts:10,tc:6,bg:7,fh:4,po:2}];
const SH=(c,a)=>{const n=parseInt(c.slice(1),16);let r=n>>16,g=n>>8&255,b=n&255;const t=a<0?0:255,p=Math.abs(a);r=Math.round(r+(t-r)*p);g=Math.round(g+(t-g)*p);b=Math.round(b+(t-b)*p);return'#'+((1<<24)+(r<<16)+(g<<8)+b).toString(16).slice(1)};
let AVU=0;
const avP=(d,f,x)=>`<path d="${d}" fill="${f}"${x||''}/>`,avS=(d,c,w,x)=>`<path d="${d}" stroke="${c}" stroke-width="${w}" fill="none" stroke-linecap="round" stroke-linejoin="round"${x||''}/>`;
const CAP='M20.5 27Q18.5 12 32 12Q46 12 43.5 27Q42 18 36 17Q28 21 22 20Q21 23 20.5 27z';
const HAIR=[
()=>['',''],
(h,d,l)=>['',avP(CAP,h)+avS('M25 15.4Q32 12.6 39 15.4',l,1,' opacity=".55"')],
(h)=>['',avP('M21.5 25Q20.5 14.5 32 14Q43.5 14.5 42.5 25Q41.5 19.5 32 18.5Q22.5 19.5 21.5 25z',h,' opacity=".6"')],
(h,d,l)=>['',avP('M19.8 27Q15 9 31 8Q47 8 44.2 27Q42 17 35 15.5Q27 14 21.5 21z',h)+avS('M24 15Q31 8.6 41 13',l,1,' opacity=".55"')+avS('M30 11Q36 14 38 18',d,.8,' opacity=".7"')],
(h,d,l)=>['',avP('M20.4 27Q18.4 11 31 11Q46 11 43.8 27Q42 20 37 18Q31 21 26 18Q22 19 20.4 27z',h)+avS('M27 12.5Q29.6 16 27 19.2',d,.9)+avS('M24 15Q31 11.8 40 14.6',l,1,' opacity=".5"')],
(h,d)=>['',avP('M19.5 29Q17.5 10 32 10.5Q46.5 10 44.5 29Q43 21 40 19.5Q32 22 24 19.5Q21 21 19.5 29z',h)+avS('M24 19.8Q32 22.4 40 19.8',d,.8,' opacity=".6"')],
(h,d,l)=>['',avP('M20 26Q14 8 30 6.5Q48 7 44 26Q42 15 33 14.5Q24 15 20 26z',h)+avS('M22 14Q29 6.5 41 12',l,1.1,' opacity=".5"')+avS('M28 9.5Q33 12 34 15',d,.8,' opacity=".7"')],
(h,d,l)=>['',[[22,19,4.6],[26.6,14.4,5],[32,12.4,5.2],[37.4,14.4,5],[42,19,4.6],[19.6,25,3.4],[44.4,25,3.4],[28,17.6,3.6],[36,17.6,3.6]].map(a=>`<circle cx="${a[0]}" cy="${a[1]}" r="${a[2]}" fill="${h}"/>`).join('')+[[26,13],[35,12.5],[41,17],[22,17]].map(a=>`<circle cx="${a[0]}" cy="${a[1]}" r="1.6" fill="${l}" opacity=".5"/>`).join('')],
(h,d,l)=>[`<circle cx="32" cy="21" r="18.6" fill="${h}"/><circle cx="19" cy="30" r="6" fill="${h}"/><circle cx="45" cy="30" r="6" fill="${h}"/>`,[[24,16.6],[29,15],[35,15],[40,16.6]].map(a=>`<circle cx="${a[0]}" cy="${a[1]}" r="3.6" fill="${h}"/>`).join('')+`<circle cx="25" cy="8.4" r="3" fill="${l}" opacity=".35"/><circle cx="37" cy="9" r="2.4" fill="${l}" opacity=".3"/>`],
(h,d,l)=>[`<circle cx="32" cy="7.6" r="5.4" fill="${h}"/><path d="M28.4 10.4Q32 12.6 35.6 10.4" stroke="${d}" stroke-width=".9" fill="none"/>`,avP(CAP,h)+`<path d="M29 5.6Q32 4.2 35 5.6" stroke="${l}" stroke-width="1" fill="none" opacity=".5"/>`],
(h,d,l)=>[`<circle cx="44.6" cy="13.6" r="5.2" fill="${h}"/><circle cx="44.6" cy="13.6" r="2" fill="${d}" opacity=".5"/>`,avP('M20.4 27Q18.4 11 31 11Q46 11 43.8 27Q42 20 37 18Q31 21 26 18Q22 19 20.4 27z',h)],
(h,d,l)=>[avP('M42 18Q57 17 55 36Q54 44 49 48Q50 38 46 30z',h)+avP('M42 18Q55 18 54 32Q52 26 46 24z',l,' opacity=".25"'),avP(CAP,h)+`<ellipse cx="43.4" cy="19" rx="1.9" ry="1.5" fill="#e05a7a"/>`],
(h,d)=>['<path d="M21 22Q9 24 11.5 40Q12.5 46 17 48Q16 38 21 30z" fill="'+h+'"/><path d="M43 22Q55 24 52.5 40Q51.5 46 47 48Q48 38 43 30z" fill="'+h+'"/>',avP(CAP,h)+'<circle cx="20.4" cy="22.4" r="1.9" fill="#e05a7a"/><circle cx="43.6" cy="22.4" r="1.9" fill="#e05a7a"/>'],
(h,d,l)=>[avP('M18.2 27Q15.5 50 22 52.5L42 52.5Q48.5 50 45.8 27Q46 10 32 10Q18 10 18.2 27z',h)+avS('M20 40Q19.6 46 22 50',l,1,' opacity=".35"'),avP('M19.6 29Q17.6 10.5 32 10.5Q46.4 10.5 44.4 29Q43 20 36 17.5Q29 20.5 22 19.5Q20.4 22 19.6 29z',h)+avS('M26 12.4Q29 16 27 19',d,.9,' opacity=".7"')],
(h,d)=>[avP('M18.4 27Q16 44 21 47Q24 47.5 25 45L39 45Q40 47.5 43 47Q48 44 45.6 27Q46 10 32 10Q18 10 18.4 27z',h),avP('M19.6 30Q17.6 10.5 32 10.5Q46.4 10.5 44.4 30Q44 24 41 20Q32 23.4 23 20Q20 24 19.6 30z',h)+avS('M24 20.6Q32 23.4 40 20.6',d,.8,' opacity=".6"')],
(h,d,l)=>[avP('M17.4 30Q14 54 19 60L45 60Q50 54 46.6 30Q47 8 32 8Q17 8 17.4 30z',h)+avS('M19 40Q18.4 50 20.6 57',l,1.1,' opacity=".3"')+avS('M45 40Q45.6 50 43.4 57',d,1.1,' opacity=".4"'),avP('M19.6 29Q17.6 10.5 32 10.5Q46.4 10.5 44.4 29Q43 20 36 17.5Q29 20.5 22 19.5Q20.4 22 19.6 29z',h)+avS('M27 12.4Q30 16 28 19',d,.9,' opacity=".7"')],
(h,d,l)=>[avP('M17.4 30Q13 44 16 52Q14 58 20 62Q26 58 32 62Q38 58 44 62Q50 58 48 52Q51 44 46.6 30Q47 8 32 8Q17 8 17.4 30z',h)+avS('M20 42Q17.4 48 20 54M44 42Q46.6 48 44 54',d,1,' opacity=".5"'),avP('M19.6 29Q17.6 10.5 32 10.5Q46.4 10.5 44.4 29Q43 20 36 17.5Q29 20.5 22 19.5Q20.4 22 19.6 29z',h)+avS('M24 14Q30 11.6 40 14',l,1,' opacity=".4"')],
(h,d)=>[avP('M17.4 30Q14 54 19 60L45 60Q50 54 46.6 30Q47 8 32 8Q17 8 17.4 30z',h),avP('M19.6 30Q17.6 10.5 32 10.5Q46.4 10.5 44.4 30Q44 24 41 20Q32 23.4 23 20Q20 24 19.6 30z',h)+avS('M24 20.6Q32 23.4 40 20.6',d,.8,' opacity=".6"')],
(h,d,l)=>[avP('M18 28Q16 40 20 46L44 46Q48 40 46 28Q46 10 32 10Q18 10 18 28z',h)+[[46,34],[47.6,39.4],[48.6,45],[49,50.6],[49,56]].map((a,i)=>`<ellipse cx="${a[0]}" cy="${a[1]}" rx="3.4" ry="3" fill="${i%2?h:d}"/>`).join('')+'<circle cx="49" cy="59" r="1.8" fill="#e05a7a"/>',avP('M19.6 29Q17.6 10.5 32 10.5Q46.4 10.5 44.4 29Q43 20 36 17.5Q29 20.5 22 19.5Q20.4 22 19.6 29z',h)+avS('M27 12.4Q30 16 28 19',d,.9,' opacity=".7"')],
(h,d,l)=>['',avP('M20.5 28Q17 11 33 10Q47 11 43.5 27Q41 19 36 18Q30 14 22 22z',h)+avS('M26 13Q34 11 40 15',l,1,' opacity=".5"')],
(h,d,l)=>[avP('M18 30Q15.6 46 20 56L44 56Q48.4 46 46 30Q46 10 32 10Q18 10 18 30z',h),avP('M20 28Q18 10 33 10.5Q46 11 44 27Q38 20 30 16.5Q24 20 20 28z',h)+avS('M23 17Q30 12 40 14',l,1,' opacity=".45"')],
(h,d,l)=>[`<circle cx="23" cy="10.6" r="5.2" fill="${h}"/><circle cx="41" cy="10.6" r="5.2" fill="${h}"/><circle cx="23" cy="10.6" r="2" fill="${d}" opacity=".45"/><circle cx="41" cy="10.6" r="2" fill="${d}" opacity=".45"/>`,avP(CAP,h)],
(h,d,l)=>[[20,22.6,25.4,38.6,41.4,44].map((x,i)=>`<path d="M${x} 18V${i%3==1?40:46}" stroke="${i%2?h:d}" stroke-width="3.4" stroke-linecap="round"/><path d="M${x-.7} 20V${i%3==1?36:42}" stroke="${l}" stroke-width=".7" opacity=".3"/>`).join(''),avP(CAP,h)],
(h,d,l)=>[`<circle cx="32" cy="36" r="19.4" fill="${h}"/><circle cx="17.4" cy="44" r="5.6" fill="${h}"/><circle cx="46.6" cy="44" r="5.6" fill="${h}"/><circle cx="19" cy="52.6" r="5" fill="${h}"/><circle cx="45" cy="52.6" r="5" fill="${h}"/><circle cx="32" cy="14" r="8" fill="${h}"/>`,[[22,18,4.6],[27,14,4.6],[32,12.4,4.8],[37,14,4.6],[42,18,4.6],[19.6,26,3.4],[44.4,26,3.4]].map(a=>`<circle cx="${a[0]}" cy="${a[1]}" r="${a[2]}" fill="${h}"/>`).join('')+`<circle cx="26" cy="13" r="1.5" fill="${l}" opacity=".45"/><circle cx="38" cy="13.6" r="1.4" fill="${l}" opacity=".4"/>`],
(h,d,l)=>['',avP('M28.4 19Q27.6 6 32 3.4Q36.4 6 35.6 19z',h)+avP('M21.4 25Q21.6 16 27.4 16Q23 19 22.6 25z',h,' opacity=".5"')+avP('M42.6 25Q42.4 16 36.6 16Q41 19 41.4 25z',h,' opacity=".5"')+avS('M32 5.4V16',l,1,' opacity=".45"')],
(h,d,l)=>['',avP('M20.4 26Q18.6 18 21 12L25 17 27 8 31 15 34 6 37 15 41 9 43 17 45 12Q45.4 20 43.6 26Q42 19.5 36 18Q29 20.5 22 19.6Q21 22.5 20.4 26z',h)],
(h,d,l)=>['',avP('M20 27Q18 11 31 10Q48 9 44 26Q40 17 33 17Q26 18 20 27z',h)+avP('M22 17Q36 7 46 20Q41 13 31 13Q26 14 22 17z',l,' opacity=".5"')],
(h,d,l)=>[avP('M18.4 27Q15 42 11.5 48Q18 52 23 47L23 30z',h)+avP('M45.6 27Q49 42 52.5 48Q46 52 41 47L41 30z',h),avP('M18.4 27Q18 10 32 10Q46 10 45.6 27Q44 24 41 20Q32 23.4 23 20Q20 24 18.4 27z',h)+avS('M24 20.6Q32 23.4 40 20.6',d,.8,' opacity=".6"')]
];
const BGP=[()=>'',(c)=>{let s='';for(let y=6;y<64;y+=11)for(let x=(y/11%2)*5.5+4;x<64;x+=11)s+=`<circle cx="${x}" cy="${y}" r="1.7" fill="#fff" opacity=".5"/>`;return s},()=>{let s='';for(let x=-64;x<80;x+=9)s+=`<path d="M${x} 70L${x+64} 0" stroke="#fff" stroke-width="3.4" opacity=".38"/>`;return s},()=>{let s='';for(let i=0;i<9;i++){const a=i*Math.PI/9-Math.PI;s+=`<path d="M32 64L${32+Math.cos(a)*80} ${64+Math.sin(a)*80}L${32+Math.cos(a+.17)*80} ${64+Math.sin(a+.17)*80}z" fill="#fff" opacity=".35"/>`}return s},()=>[[10,10],[52,14],[44,6],[12,40],[56,40],[8,26]].map((a,i)=>`<path d="M${a[0]} ${a[1]-3}L${a[0]+.9} ${a[1]-.9}L${a[0]+3} ${a[1]}L${a[0]+.9} ${a[1]+.9}L${a[0]} ${a[1]+3}L${a[0]-.9} ${a[1]+.9}L${a[0]-3} ${a[1]}L${a[0]-.9} ${a[1]-.9}z" fill="#fff" opacity=".8"/>`).join(''),()=>[10,22,34,46].map(y=>`<path d="M-2 ${y}Q6 ${y-5} 14 ${y}T30 ${y}T46 ${y}T62 ${y}T78 ${y}" stroke="#fff" stroke-width="2" fill="none" opacity=".4"/>`).join(''),()=>[[8,12,30],[54,10,-20],[6,36,-40],[58,34,50],[50,52,10]].map(a=>`<ellipse cx="${a[0]}" cy="${a[1]}" rx="2.6" ry="6" fill="#fff" opacity=".4" transform="rotate(${a[2]} ${a[0]} ${a[1]})"/>`).join(''),()=>{let s='';for(let y=0;y<64;y+=8)for(let x=0;x<64;x+=8)if((x+y)/8%2)s+=`<rect x="${x}" y="${y}" width="8" height="8" fill="#fff" opacity=".28"/>`;return s}];
const HATFULL=[1,2,3,4,5,9,11,12];
const TOP=[
(t,t2,tl)=>({g:'CREW',post:avS('M25 44.5Q32 49.5 39 44.5',t2,1.4)}),
(t,t2,tl)=>({g:'VNK',post:avS('M25 44.5L32 55 39 44.5',t2,1.4)}),
(t,t2,tl)=>({g:'M7 64Q9 46 25 44.5L32 52 39 44.5Q55 46 57 64z',post:avP('M24 44L31 51.6 27.2 53.4 21.6 47z',tl)+avP('M40 44L33 51.6 36.8 53.4 42.4 47z',tl)+avS('M32 52V63',t2,1)+'<circle cx="32" cy="55.6" r=".9" fill="#fff"/><circle cx="32" cy="59.6" r=".9" fill="#fff"/>'}),
(t,t2,tl)=>({pre:avP('M17 51Q19 39.6 32 39.6Q45 39.6 47 51Q32 46 17 51z',t2),g:'M7 64Q9 46 24 44.5Q32 50 40 44.5Q55 46 57 64z',post:avS('M28.4 49.6V57M35.6 49.6V57',tl,1.2)+'<circle cx="28.4" cy="57.4" r="1" fill="#fff"/><circle cx="35.6" cy="57.4" r="1" fill="#fff"/>'+avS('M19 64Q22 57 32 57Q42 57 45 64',t2,1,' opacity=".8"')}),
(t,t2,tl)=>({g:'M7 64Q9 46 25 44.5L32 50 39 44.5Q55 46 57 64z',post:avP('M24.4 44L31.6 50.4 31 54 22.4 47.4z',tl)+avP('M39.6 44L32.4 50.4 33 54 41.6 47.4z',tl)+avS('M32 52V64',t2,1)+[55,59.6].map(y=>`<circle cx="32" cy="${y}" r=".9" fill="${t2}"/>`).join('')}),
(t,t2,tl)=>({g:'VNK',post:avP('M26 45L32 55.6 38 45Q32 50 26 45z','#fff')+avP('M25 44.5L30.6 57 24 62 20 50z',t2)+avP('M39 44.5L33.4 57 40 62 44 50z',t2)+avP('M32 49.6l-2 3 2 11 2-11z','#c9453a')}),
(t,t2,tl)=>({g:'VNK',post:avP('M26 45L32 55.6 38 45Q32 50 26 45z','#fff')+avP('M25 44.5L30.6 57 24 62 20 50z',t2)+avP('M39 44.5L33.4 57 40 62 44 50z',t2)+avP('M32 50.4l-5.4-2.8v5.6zM32 50.4l5.4-2.8v5.6z','#c9453a')+'<circle cx="32" cy="50.4" r="1.2" fill="#a73328"/>'}),
(t,t2,tl)=>({g:'CREW',post:avP('M25.4 38.4h13.2v8.8Q32 50 25.4 47.2z',t)+[41,43.6,46].map(y=>avS(`M25.8 ${y}Q32 ${y+1.6} 38.2 ${y}`,t2,.7,' opacity=".6"')).join('')}),
(t,t2,tl)=>({g:'M14 64Q15 53 23 47Q27 45 27 44.5Q32 50 37 44.5Q41 45 41 47Q49 53 50 64z',post:''}),
(t,t2,tl)=>({g:'CREW',fillOv:tl,post:avP('M21 64V53Q21 50 24.4 50H39.6Q43 50 43 53V64z','#4f6fa0')+avS('M24.4 50L22.6 44.6M39.6 50L41.4 44.6','#4f6fa0',2.4)+'<circle cx="24" cy="51.6" r="1" fill="#e8c35a"/><circle cx="40" cy="51.6" r="1" fill="#e8c35a"/><rect x="28" y="55" width="8" height="5.6" rx="1" fill="#3f5c8a"/>'}),
(t,t2,tl)=>({g:'VNK',post:avS('M25 44.5L32 55 39 44.5','#fff',1.8)+avS('M10 64Q11 54 14 49M54 64Q53 54 50 49','#fff',1.6)+avS('M29 57h6l-3 7','#fff',1.4)}),
(t,t2,tl)=>({g:'CREW',post:avS('M25 44.5Q32 49.5 39 44.5','#e8bf55',2)+[10,16,22,28,34,40,46,52].map(x=>`<path d="M${x+2} 58.6l1.8 2.4-1.8 2.4-1.8-2.4z" fill="#e8bf55"/>`).join('')}),
(t,t2,tl)=>({g:'CREW',post:avP('M16 46.4L24 44.6 56 62.5V64H44z','#f7e6bd')+avS('M16.4 46.6L44 64M24 44.6L56 62.5','#d9a93a',1)}),
(t,t2,tl)=>({g:'M7 64Q9 46 25 44.5L32 50 39 44.5Q55 46 57 64z',post:avP('M24 44L31 50.6 27.2 53.6 21.6 47z',tl)+avP('M40 44L33 50.6 36.8 53.6 42.4 47z',tl)+avP('M27.4 47.2L32 52.6 36.6 47.2Q32 49.2 27.4 47.2z','#1f3a7a')+'<circle cx="40.6" cy="57" r="2" fill="#1f3a7a"/><circle cx="40.6" cy="57" r=".7" fill="#e8c35a"/>'+avS('M32 53V64',t2,.8)}),
(t,t2,tl)=>({g:'M7 64Q9 46 25 44.5L32 50 39 44.5Q55 46 57 64z',post:avS('M25 44.5L40 61',t2,1.7)+avS('M39 44.5L26 61',t2,1.7)+avS('M41 58l3 3M41 61l3 3',t2,1)}),
(t,t2,tl)=>({g:'CREW',post:avP('M25.4 43.8h13.2v4.4Q32 49.6 25.4 48z',tl)+avS('M32 49.4V64',t2,.9)+[53,58].map(y=>`<circle cx="32" cy="${y}" r="1.1" fill="#e8c35a"/><path d="M29.6 ${y}h-1.6M34.4 ${y}h1.6" stroke="#e8c35a" stroke-width=".8"/>`).join('')}),
(t,t2,tl)=>({g:'M7 64Q9 46 24 44.5Q32 49 40 44.5Q55 46 57 64z',post:avP('M23.6 44.8Q32 50.8 40.4 44.8L41 47.4Q32 54 23 47.4z',t2)+[26,29,32,35,38].map(x=>avS(`M${x} 46.4V51`,tl,.6,' opacity=".6"')).join('')+avS('M32 52V64','#d7d7d7',1.1)+avS('M17 60h6M41 60h6',t2,1)}),
(t,t2,tl)=>({g:'CREW',post:avP('M26 45.4Q32 51 38 45.4L36.4 64H27.6z',tl)+avS('M26 45.4L27.6 64M38 45.4L36.4 64',t2,1)+[52,57,62].map(y=>`<circle cx="40" cy="${y}" r=".9" fill="${t2}"/>`).join('')}),
(t,t2,tl)=>({g:'CREW',post:avP('M24 44.6Q32 52 40 44.6L42 49Q32 56 22 49z','#e05a47')+avP('M36 52l6.4 11-5 1-4.4-9.6z','#c8483a')+avS('M38 56l3 5.4M40 55l3 5.6','#a73328',.6)}),
(t,t2,tl)=>({g:'CREW',post:avP('M25.4 43.8h13.2v4.4Q32 49.6 25.4 48z',tl)+avS('M32 49.4V64',t2,.9)+[[28.4,54],[28.4,59],[35.6,54],[35.6,59]].map(a=>`<circle cx="${a[0]}" cy="${a[1]}" r="1" fill="${t2}"/>`).join('')+avP('M28 46.8L32 52 36 46.8Q32 48.6 28 46.8z','#d9503f')}),
(t,t2,tl)=>({g:'VNK',post:avP('M26 45L32 54.6 38 45Q32 50 26 45z','#3fa89b')+avP('M25 44.5L30 58 22 62 19 50z',tl)+avP('M39 44.5L34 58 42 62 45 50z',tl)+avS('M26 46Q24 56 29 58Q34 59 35.4 54','#3a3a40',.9)+'<circle cx="36" cy="53" r="1.6" fill="#b8b8c0"/><rect x="38" y="56" width="4" height="5" rx=".8" fill="#fff" stroke="'+t2+'" stroke-width=".5"/>'}),
(t,t2,tl)=>({g:'M9 64Q11 50 20 47Q26 51.6 32 48.4Q38 51.6 44 47Q53 50 55 64z',post:avP('M32 52l-4.4-2.4v4.8zM32 52l4.4-2.4v4.8z',t2)+'<circle cx="32" cy="52" r="1.2" fill="'+t2+'"/>'+avS('M20 47Q19 44.4 21 43.4M44 47Q45 44.4 43 43.4',t,1.8)+avS('M20 47.4Q26 51.6 32 48.8Q38 51.6 44 47.4',tl,.8,' opacity=".8"')})
];
const HATS=[
()=>'',
(c,d)=>avP('M19.5 22Q20 6 32 6Q44 6 44.5 22Q32 18 19.5 22z',c)+avP('M19.6 21.4Q32 24.6 44.4 21.4L45 24Q32 28.6 19 24z',d)+'<circle cx="32" cy="6.2" r="1.3" fill="'+d+'"/>'+avS('M25 11Q28 7.6 33 7.4','#fff',1,' opacity=".35"'),
(c,d)=>avP('M19 24Q18 6 32 6Q46 6 45 24Q32 20 19 24z',c)+avP('M18.5 23.6Q32 20 45.5 23.6L45.2 28Q32 24.4 18.8 28z',d)+[22,26,30,34,38,42].map(x=>avS(`M${x} 22.6V27`,c,.7,' opacity=".6"')).join('')+`<circle cx="32" cy="5.4" r="3.4" fill="${c}"/><circle cx="31" cy="4.6" r="1.2" fill="#fff" opacity=".3"/>`,
(c,d)=>avP('M23 20Q23 8 32 8Q41 8 41 20z',c)+avP('M9 21Q9 17 32 17Q55 17 55 21Q55 25.6 32 25.6Q9 25.6 9 21z',SH(c,.25))+avP('M23 19.2Q32 22 41 19.2L41 20.4Q32 23.6 23 20.4z',d)+avS('M12 22Q32 27 52 22',d,.6,' opacity=".5"'),
(c,d)=>avP('M8 22L32 5 56 22Q32 26.6 8 22z','#e4c27a')+avP('M32 5L56 22Q44 25 32 24.6z','#c9a45c',' opacity=".6"')+[[14,14],[22,16],[30,13],[38,14],[46,16]].map(a=>avS(`M32 5L${a[0]*1.1-3} 23`,'#a9843c',.5,' opacity=".6"')).join('')+avS('M9 22Q32 26 55 22','#a9843c',1)+'<path d="M20.5 24Q19.6 34 22 39M43.5 24Q44.4 34 42 39" stroke="'+d+'" stroke-width=".9" fill="none"/>',
(c,d)=>'<circle cx="23" cy="12" r="6.4" fill="#fff"/><circle cx="32" cy="8.6" r="7.4" fill="#fff"/><circle cx="41" cy="12" r="6.4" fill="#fff"/>'+avP('M21 12Q32 9 43 12V20Q32 17 21 20z','#fff')+avP('M21 17.4Q32 14.6 43 17.4V22Q32 19.4 21 22z','#e9e9e4')+avS('M26 9Q29 7 32 8M36 12Q39 10 41 12','#dcdcd4',.9),
(c,d)=>avS('M20.5 21.6Q32 15.6 43.5 21.6',c,3.2)+avS('M21 21Q32 15.4 43 21',SH(c,.3),.8,' opacity=".6"'),
(c,d)=>avP('M40.4 14Q33 8 33.4 15z',c)+avP('M40.4 14Q47.4 8.4 47 16z',c)+avP('M39.4 12.6l2.4.6.6 2.6-2.4-.6z',d)+avS('M36 13.6L38 14.4',SH(c,.4),.8),
(c,d)=>[[22,20.4],[26.6,17.6],[32,16.6],[37.4,17.6],[42,20.4]].map((a,i)=>`<g transform="translate(${a[0]} ${a[1]})">${[0,72,144,216,288].map(r=>`<ellipse cy="-1.9" rx="1.2" ry="1.9" fill="${['#fff','#ffc4d6','#fff','#ffe08a','#fff'][i]}" transform="rotate(${r})"/>`).join('')}<circle r=".9" fill="#f8c630"/></g>`).join('')+avS('M20.6 22Q32 15.4 43.4 22','#58a74a',.9,' opacity=".6"'),
(c,d)=>avP('M19.6 22Q20 8.6 32 8.6Q44 8.6 44.4 22Q32 17 19.6 22z',c)+avP('M42 20Q50 21 51.6 30Q49 26 44 25.6z',c)+[[24,12.4],[30,10.6],[37,12],[41,16],[27,17.4]].map(a=>`<circle cx="${a[0]}" cy="${a[1]}" r="1.1" fill="#fff" opacity=".55"/>`).join('')+avS('M20 21.8Q32 17.2 44 21.8',d,1.1,' opacity=".5"'),
(c,d)=>avP('M20 17L21.6 4.4 29.4 11.2z',c)+avP('M44 17L42.4 4.4 34.6 11.2z',c)+avP('M22 14L22.8 7.6 26.8 11.4z','#ffb8c8')+avP('M42 14L41.2 7.6 37.2 11.4z','#ffb8c8')+avS('M20.4 22Q32 15.4 43.6 22',SH(c,-.2),2.2),
(c,d)=>avP('M19.4 22Q20 9 32 9Q44 9 44.6 22Q32 18.4 19.4 22z',c)+avP('M16.6 22Q32 13 47.4 22Q49.4 27 44 26Q32 21.6 20 26Q14.6 27 16.6 22z',d)+avS('M19.4 22Q32 17.6 44.6 22',SH(c,.4),.8,' opacity=".6"'),
(c,d)=>avP('M17.6 19Q22 6.6 36 7.4Q50 8.4 45.6 19.6Q32 16.4 17.6 19z',c)+'<rect x="31.2" y="3.8" width="1.8" height="3.8" rx=".8" fill="'+d+'"/>'+avS('M24 12Q29 8.6 36 9',SH(c,.4),1,' opacity=".5"')
];
const EYES=[
(k,ic)=>[26.5,37.5].map(x=>`<ellipse cx="${x}" cy="27.5" rx="2.7" ry="2.3" fill="#fff"/><circle cx="${x+.3}" cy="27.7" r="1.7" fill="${ic}"/><circle cx="${x+.3}" cy="27.7" r=".8" fill="#1b100b"/><circle cx="${x+.9}" cy="27" r=".6" fill="#fff"/><path d="M${x-3} 26.2Q${x} 24.4 ${x+3} 26.2" stroke="#2b1b14" stroke-width=".9" fill="none"/>`).join(''),
()=>avS('M23.5 27.8Q26.5 24.4 29.5 27.8M34.5 27.8Q37.5 24.4 40.5 27.8','#2b1b14',1.5),
(k,ic)=>[26.5,37.5].map(x=>`<ellipse cx="${x}" cy="27.8" rx="2.6" ry="2" fill="#fff"/><circle cx="${x+.2}" cy="28.4" r="1.4" fill="${ic}"/><path d="M${x-2.8} 27.6Q${x} 24.6 ${x+2.8} 27.6z" fill="${k}"/><path d="M${x-3} 27.6Q${x} 26 ${x+3} 27.6" stroke="#2b1b14" stroke-width="1.1" fill="none" stroke-linecap="round"/>`).join(''),
(k,ic)=>`<ellipse cx="26.5" cy="27.5" rx="2.7" ry="2.3" fill="#fff"/><circle cx="26.8" cy="27.7" r="1.7" fill="${ic}"/><circle cx="26.8" cy="27.7" r=".8" fill="#1b100b"/><circle cx="27.4" cy="27" r=".6" fill="#fff"/><path d="M23.5 26.2Q26.5 24.4 29.5 26.2" stroke="#2b1b14" stroke-width=".9" fill="none"/>`+avS('M34.5 27.8Q37.5 24.8 40.5 27.8','#2b1b14',1.5)+'<path d="M42 23.4l.6 1.4 1.4.4-1.2.8.2 1.4-1.2-.9-1.3.6.5-1.4z" fill="#ffd05a"/>',
(k,ic)=>[26.5,37.5].map(x=>`<ellipse cx="${x}" cy="27.4" rx="3.2" ry="3.2" fill="#fff"/><circle cx="${x+.2}" cy="27.8" r="2.4" fill="${ic}"/><circle cx="${x+.2}" cy="27.8" r="1.2" fill="#1b100b"/><circle cx="${x+1.1}" cy="26.7" r=".9" fill="#fff"/><circle cx="${x-.8}" cy="28.8" r=".5" fill="#fff"/><path d="M${x-3.4} 26Q${x} 23.4 ${x+3.4} 26" stroke="#2b1b14" stroke-width="1.1" fill="none"/>`).join(''),
(k,ic)=>EYES[0](k,ic)+avS('M23.4 26.4l-1.8-1M24.4 25.4l-1.2-1.8M40.6 26.4l1.8-1M39.6 25.4l1.2-1.8','#2b1b14',.8),
(k,ic)=>[[23.3,29.8,26.5],[34.2,40.7,37.5]].map(a=>`<path d="M${a[0]} 27.8Q${a[2]} 24.4 ${a[1]} 27.6Q${a[2]} 29.8 ${a[0]} 27.8z" fill="#fff"/><circle cx="${a[2]+.2}" cy="27.5" r="1.6" fill="${ic}"/><circle cx="${a[2]+.2}" cy="27.5" r=".7" fill="#1b100b"/><path d="M${a[0]} 27.8Q${a[2]} 24.2 ${a[1]} 27.6" stroke="#2b1b14" stroke-width="1" fill="none" stroke-linecap="round"/>`).join(''),
(k,ic)=>[26.5,37.5].map(x=>`<ellipse cx="${x}" cy="27.4" rx="3.1" ry="3.5" fill="#fff" stroke="#2b1b14" stroke-width=".6"/><circle cx="${x}" cy="27.6" r="1.2" fill="#1b100b"/>`).join(''),
()=>avP('M23.4 28.4Q26.5 23.6 29.6 28.4Q26.5 26.4 23.4 28.4z','#2b1b14')+avP('M34.4 28.4Q37.5 23.6 40.6 28.4Q37.5 26.4 34.4 28.4z','#2b1b14'),
()=>[26.5,37.5].map(x=>`<circle cx="${x}" cy="27.6" r="1.8" fill="#2b1b14"/><circle cx="${x+.6}" cy="27" r=".6" fill="#fff"/>`).join(''),
(k,ic)=>EYES[0](k,ic)+avS('M23.6 30.4Q26.5 31.8 29.4 30.4M34.6 30.4Q37.5 31.8 40.4 30.4',SH(k,-.28),.8,' opacity=".8"'),
(k,ic)=>EYES[0](k,ic)+avS('M22.8 26Q26.5 24.6 30 25.6M41.2 26Q37.5 24.6 34 25.6','#2b1b14',1.1)
];
const BROW=[
(b)=>avS('M22.5 23.2Q26.5 21 30 22.6M34 22.6Q37.5 21 41.5 23.2',b,1.4),
(b)=>avS('M22.4 23.4Q26.5 20.6 30 22.4M34 22.4Q37.5 20.6 41.6 23.4',b,2.5),
(b)=>avS('M22.5 23Q26.5 21.2 30 22.4M34 22.4Q37.5 21.2 41.5 23',b,.9),
(b)=>avS('M22.5 22Q26.5 19 30 21M34 21Q37.5 19 41.5 22',b,1.4),
(b)=>avS('M22.5 21.6L30 23.6M41.5 21.6L34 23.6',b,1.7),
(b)=>avS('M22.5 23.6L30 21.6M41.5 23.6L34 21.6',b,1.4),
()=>'',
(b)=>avS('M24 22.8Q26.5 21.6 29 22.4M35 22.4Q37.5 21.6 40 22.8',b,1.7)
];
const NOSE=[(k,kd)=>avS('M32 28.5q-1.5 3.2 0 4.2',kd,1,' opacity=".6"'),(k,kd)=>avS('M32 28.2v3.6q-1.5.9-2.5.2',kd,.9,' opacity=".7"'),(k,kd)=>`<ellipse cx="32" cy="32" rx="1.5" ry="1" fill="${kd}" opacity=".55"/>`,(k,kd)=>avP('M32 29.4l-1.7 3.2h3.4z',kd,' opacity=".32"')+'<circle cx="31" cy="32.6" r=".4" fill="'+kd+'"/><circle cx="33" cy="32.6" r=".4" fill="'+kd+'"/>'];
const MOUTH=[
()=>'<path d="M26.8 35.5Q32 41 37.2 35.5Q32 37.4 26.8 35.5z" fill="#a5413f"/><path d="M28 36.2Q32 37.8 36 36.2Q32 38.4 28 36.2z" fill="#fff"/>',
()=>avS('M27.5 36Q32 39.2 36.5 36','#b4584f',1.4),
()=>'<path d="M25.5 34.5Q32 42.5 38.5 34.5z" fill="#a5413f"/><path d="M27 35.2Q32 37 37 35.2Q32 38.4 27 35.2z" fill="#fff"/><ellipse cx="32" cy="39.6" rx="3" ry="1.4" fill="#e0675d"/>',
()=>avS('M28.5 37h7','#b4584f',1.3),
()=>avS('M28 37.4Q32 38 36.4 35.4','#b4584f',1.4),
()=>'<path d="M26.8 35.6Q32 41 37.2 35.6z" fill="#a5413f"/><ellipse cx="33" cy="39" rx="2.6" ry="2.1" fill="#f0766a"/><path d="M33 37.6v2.6" stroke="#c9544d" stroke-width=".5"/>',
()=>'<ellipse cx="32" cy="37" rx="1.7" ry="2.1" fill="#a5413f"/>',
()=>'<path d="M32 38.6q-3.4-2-1.8-3.6Q32 33.6 32 35.6Q32 33.6 33.8 35Q35.4 36.6 32 38.6z" fill="#d1524f"/>',
()=>avS('M27.6 38.4Q32 34.8 36.4 38.4','#b4584f',1.4),
()=>avS('M27.6 36.2Q29.8 38.4 32 36.2Q34.2 38.4 36.4 36.2','#b4584f',1.3)
];
const FHAIR=[()=>'',(h)=>avP('M26.5 34.6Q29 32.6 32 34Q35 32.6 37.5 34.6Q35 36.2 32 35Q29 36.2 26.5 34.6z',h),(h)=>avP('M29.5 38.4Q32 36.6 34.5 38.4Q34 42.6 32 43.2Q30 42.6 29.5 38.4z',h),(h)=>avP('M20.8 30Q20.4 44.4 32 45Q43.6 44.4 43.2 30Q41 38.4 38 36.6Q32 34.4 26 36.6Q23 38.4 20.8 30z',h)+avP('M26.5 34.4Q29 32.4 32 33.8Q35 32.4 37.5 34.4Q35 36 32 35Q29 36 26.5 34.4z',h),(h)=>avP('M21.6 31Q22 42 32 42.6Q42 42 42.4 31Q40 37.4 36 36.6Q32 35.4 28 36.6Q24 37.4 21.6 31z',h,' opacity=".32"'),(h)=>avP('M24.4 33.4Q26 36.6 29 34.6Q32 33 35 34.6Q38 36.6 39.6 33.4Q37.4 38.4 34.6 36.4Q32 35.4 29.4 36.4Q26.6 38.4 24.4 33.4z',h),(h)=>avP('M30.6 39.6Q32 38.6 33.4 39.6Q33 41.4 32 41.6Q31 41.4 30.6 39.6z',h)];
const EXTRA=[()=>'',(k,kd)=>[[25,32],[27.4,33.6],[23.6,33.8],[39,32],[36.6,33.6],[40.4,33.8],[29.4,31.2],[34.6,31.2],[32,32.6]].map(a=>`<circle cx="${a[0]}" cy="${a[1]}" r=".45" fill="#8a4a2a" opacity=".7"/>`).join(''),()=>'<ellipse cx="24.6" cy="33.2" rx="3.4" ry="2.4" fill="#ff6f8a" opacity=".5"/><ellipse cx="39.4" cy="33.2" rx="3.4" ry="2.4" fill="#ff6f8a" opacity=".5"/>',()=>'<circle cx="36.6" cy="33.6" r=".7" fill="#3a2418"/>',()=>[[22.6,31],[22.2,33],[23,35],[41.4,31],[41.8,33],[41,35]].map((a,i)=>`<path d="M${a[0]} ${a[1]}h${i<3?4:-4}" stroke="#e8d27a" stroke-width="1.6" stroke-linecap="round" opacity=".8"/>`).join(''),()=>'<g transform="rotate(-24 38 33)"><rect x="34.4" y="31.6" width="7.4" height="3.2" rx="1.4" fill="#f2cfa0"/><rect x="36.6" y="31.6" width="3" height="3.2" fill="#e6b57e"/></g>',()=>'<path d="M24.6 31.6q1.6-1.8 2.2.1-.5 1.3-2.2 2.6-1.7-1.3-2.2-2.6.6-1.9 2.2-.1z" fill="#ff5a78" opacity=".85" transform="translate(-1 .5)"/><path d="M39.6 32.4l.7 1.5 1.6.2-1.2 1.1.3 1.6-1.4-.8-1.4.8.3-1.6-1.2-1.1 1.6-.2z" fill="#ffc83a"/>'];
const GLASS=[()=>'',()=>'<circle cx="26.5" cy="27.5" r="4.7" stroke="#4a3b30" fill="#cfe9ff" fill-opacity=".25" stroke-width="1"/><circle cx="37.5" cy="27.5" r="4.7" stroke="#4a3b30" fill="#cfe9ff" fill-opacity=".25" stroke-width="1"/><path d="M31.2 27h1.6M21.8 27L19.6 26M42.2 27L44.4 26" stroke="#4a3b30" fill="none"/>',()=>'<rect x="21.6" y="23.8" width="9.6" height="7.4" rx="1.6" fill="#cfe9ff" fill-opacity=".25" stroke="#2f2f33" stroke-width="1.1"/><rect x="32.8" y="23.8" width="9.6" height="7.4" rx="1.6" fill="#cfe9ff" fill-opacity=".25" stroke="#2f2f33" stroke-width="1.1"/><path d="M31.2 26.6h1.6" stroke="#2f2f33"/>',()=>'<path d="M21.4 25.4Q21.6 23.4 24 23.8L30.4 25.2Q31.6 30.8 26.6 31Q22 31 21.4 25.4z" fill="#ffd1e6" fill-opacity=".3" stroke="#c94f8a" stroke-width="1.1"/><path d="M42.6 25.4Q42.4 23.4 40 23.8L33.6 25.2Q32.4 30.8 37.4 31Q42 31 42.6 25.4z" fill="#ffd1e6" fill-opacity=".3" stroke="#c94f8a" stroke-width="1.1"/><path d="M30.4 26h3.2" stroke="#c94f8a"/>',()=>'<rect x="21.6" y="24" width="9.8" height="6.6" rx="2.6" fill="#1d1d22"/><rect x="32.6" y="24" width="9.8" height="6.6" rx="2.6" fill="#1d1d22"/><path d="M31.4 25.8h1.2" stroke="#1d1d22" stroke-width="1.2"/><path d="M23 25.4l3 .2M34 25.4l3 .2" stroke="#fff" stroke-width=".8" opacity=".5"/>',()=>'<path d="M21.4 24.4H31Q31.4 31 26 31.2Q21.6 31 21.4 24.4z" fill="#8a6a3a" fill-opacity=".35" stroke="#c9a94a" stroke-width="1"/><path d="M42.6 24.4H33Q32.6 31 38 31.2Q42.4 31 42.6 24.4z" fill="#8a6a3a" fill-opacity=".35" stroke="#c9a94a" stroke-width="1"/><path d="M31 25h2" stroke="#c9a94a"/>',()=>'<path d="M22 27Q22 24 26.5 23.8Q31 24 31 27M33 27Q33 24 37.5 23.8Q42 24 42 27" stroke="#4a3b30" stroke-width="1.1" fill="none"/><path d="M31.2 25.6h1.6" stroke="#4a3b30"/>',()=>'<path d="M26.5 31.4Q21.4 28.6 22.4 25.6Q24.4 23.6 26.5 26Q28.6 23.6 30.6 25.6Q31.6 28.6 26.5 31.4z" fill="#ff4f7a" fill-opacity=".55" stroke="#d93a63" stroke-width=".9"/><path d="M37.5 31.4Q32.4 28.6 33.4 25.6Q35.4 23.6 37.5 26Q39.6 23.6 41.6 25.6Q42.6 28.6 37.5 31.4z" fill="#ff4f7a" fill-opacity=".55" stroke="#d93a63" stroke-width=".9"/>'];
function AVC(c,vb,th){
 c=Object.assign({},AVDEF,c||{});const u='a'+(++AVU)+'_',k=AVD.sk[c.sk],kd=SH(k,-.16),hcol=AVD.hc[c.hc],hd=SH(hcol,-.26),hl=SH(hcol,.3),ic=AVD.ic[c.ic],tc=AVD.tc[c.tc],t2=SH(tc,-.2),tl=SH(tc,.32),bg=AVD.bg[c.bg],hat=c.ht,hcl=AVD.tc[c.hl],hcl2=SH(hcl,-.22);
 const rx=[12,11.2,10.4,12.6][c.fs],ry=[13.2,14,15,12.8][c.fs],ex=rx+.7,full=HATFULL.includes(hat);
 let hs=c.hs;if(full&&[3,6,7,8,9,10,21,24,25].includes(hs))hs=1;if(full&&hs===23)hs=15;if(hat>0&&hat!==6&&hat!==7&&hat!==8&&hat!==10&&hs===0)hs=0;
 const [hb,hf]=HAIR[hs](hcol,hd,hl);
 const t=TOP[c.ts](tc,t2,tl),CREW='M7 64Q9 46 25 44.5Q32 49.5 39 44.5Q55 46 57 64z',VNK='M7 64Q9 46 25 44.5L32 55 39 44.5Q55 46 57 64z',g=t.g==='CREW'?CREW:t.g==='VNK'?VNK:t.g;
 const ptn=c.tp?`<pattern id="${u}p" width="${c.tp===3?8:6}" height="${c.tp===3?8:6}" patternUnits="userSpaceOnUse">${c.tp===1?'<rect width="6" height="2.4" fill="#fff" opacity=".4"/>':c.tp===2?'<circle cx="3" cy="3" r="1.3" fill="#fff" opacity=".5"/>':c.tp===3?'<rect width="8" height="2" fill="#000" opacity=".18"/><rect width="2" height="8" fill="#000" opacity=".18"/>':'<g fill="#fff" opacity=".6"><circle cx="2" cy="2" r="1"/><circle cx="4" cy="2" r="1"/><circle cx="3" cy="3.6" r="1"/><circle cx="3" cy="2.6" r=".5" fill="#f8c630"/></g>'}</pattern>`:'';
 let o=`<svg viewBox="${vb||'0 0 64 64'}" xmlns="http://www.w3.org/2000/svg"><defs><clipPath id="${u}c"><circle cx="32" cy="32" r="32"/></clipPath><linearGradient id="${u}g" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="${tl}" stop-opacity=".5"/><stop offset=".4" stop-color="${tc}" stop-opacity="0"/><stop offset="1" stop-color="${t2}" stop-opacity=".55"/></linearGradient><radialGradient id="${u}s" cx=".4" cy=".3" r=".8"><stop offset="0" stop-color="#fff" stop-opacity=".2"/><stop offset="1" stop-color="#000" stop-opacity=".1"/></radialGradient>${ptn}</defs>`;
 o+=`<circle cx="32" cy="32" r="32" fill="${bg}"/><g clip-path="url(#${u}c)">${BGP[c.bp](bg)}`;
 o+=hb+avP('M9 64Q10 46 32 44Q54 46 55 64z',k)+(t.pre||'')+avP('M27 38h10v9q-5 4-10 0z',k)+avP('M27 38h10v4.4q-5 3.4-10 0z','#3a1e0a',' opacity=".18"');
 o+=avP(g,t.fillOv||tc)+(c.tp?avP(g,`url(#${u}p)`):'')+avP(g,`url(#${u}g)`)+(t.post||'');
 if(c.nk===1)o+=avS('M25.6 44.8Q32 53 38.4 44.8','#e8c35a',.9);
 if(c.nk===2)o+=[0,1,2,3,4,5,6,7,8].map(i=>{const a=i/8,x=25.6+a*12.8,y=44.8+Math.sin(a*Math.PI)*7;return`<circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="1.15" fill="#fbf7ee" stroke="#d8d2c4" stroke-width=".3"/>`}).join('');
 if(c.nk===3)o+=avS('M25.6 44.8Q32 53 38.4 44.8','#e8c35a',.8)+'<path d="M32 51.4l1.6 1.8-1.6 2.4-1.6-2.4z" fill="#e0475f"/>';
 if(c.nk===4)o+=avS('M27 41.4Q32 44.8 37 41.4','#2a2a2e',1.7);
 if(c.nk===5)o+=[0,1,2,3,4,5,6,7,8,9].map(i=>{const a=i/9,x=24.4+a*15.2,y=44.4+Math.sin(a*Math.PI)*9.6;return`<g transform="translate(${x.toFixed(1)} ${y.toFixed(1)})">${i%2?'<ellipse rx="1.7" ry="1.1" fill="#6fae52"/>':[0,72,144,216,288].map(r=>`<ellipse cy="-1" rx=".8" ry="1.3" fill="#fff" transform="rotate(${r})"/>`).join('')+'<circle r=".5" fill="#f6d54a"/>'}</g>`}).join('');
 if(c.po===1)o+=`<path d="M45 54Q51 52 52 46" stroke="${tc}" stroke-width="6.4" stroke-linecap="round" fill="none"/><g transform="translate(52 43) rotate(-12)" fill="${k}"><ellipse rx="4.2" ry="4.8"/>${[-3,-1,1,3].map(x=>`<ellipse cx="${x*1.15}" cy="-5.6" rx="1.1" ry="2.6"/>`).join('')}<ellipse cx="-4.6" cy="0" rx="1.2" ry="2.6" transform="rotate(-35 -4.6 0)"/></g>`;
 if(c.po===2)o+=`<path d="M45 56Q51 55 51.6 50" stroke="${tc}" stroke-width="6.4" stroke-linecap="round" fill="none"/><g fill="${k}"><rect x="47" y="45.4" width="9" height="7.6" rx="3.4"/><path d="M48.6 46Q47.4 39.6 50.6 39.4Q53 40.2 52 46z"/></g>${avS('M48.6 49h6.6M48.6 51.2h6.6',kd,.5)}`;
 if(c.po===3)o+=`<path d="M45 56Q51 55 51.6 50" stroke="${tc}" stroke-width="6.4" stroke-linecap="round" fill="none"/><g fill="${k}"><ellipse cx="51.6" cy="49.6" rx="4.2" ry="4.4"/></g>${avS('M50 47L47.6 40M53.4 47.2L55 40.4',k,2.2)}`;
 o+=`<ellipse cx="${32-ex}" cy="29.4" rx="2.2" ry="3.2" fill="${k}"/><ellipse cx="${32+ex}" cy="29.4" rx="2.2" ry="3.2" fill="${k}"/><ellipse cx="${32-ex}" cy="29.6" rx="1" ry="1.7" fill="${kd}" opacity=".5"/><ellipse cx="${32+ex}" cy="29.6" rx="1" ry="1.7" fill="${kd}" opacity=".5"/>`;
 const E=[32-ex-.1,32+ex+.1];
 if(c.er===1)E.forEach(x=>o+=`<circle cx="${x}" cy="32.6" r="1" fill="#e8c35a"/>`);
 if(c.er===2)E.forEach(x=>o+=`<circle cx="${x}" cy="35" r="2.4" stroke="#e8c35a" stroke-width=".8" fill="none"/>`);
 if(c.er===3)E.forEach(x=>o+=avS(`M${x} 32.6V35.4`,'#e8c35a',.6)+`<circle cx="${x}" cy="36.4" r="1.3" fill="#e0475f"/>`);
 if(c.er===4)E.forEach(x=>o+=`<circle cx="${x}" cy="33" r="1.5" fill="#fbf7ee" stroke="#d8d2c4" stroke-width=".4"/>`);
 if(c.er===5)E.forEach(x=>o+=`<circle cx="${x}" cy="32" r=".9" fill="#e8c35a"/><circle cx="${x}" cy="34.4" r=".9" fill="#bde5ff"/>`);
 o+=`<ellipse cx="32" cy="28" rx="${rx}" ry="${ry}" fill="${k}"/><ellipse cx="32" cy="28" rx="${rx}" ry="${ry}" fill="url(#${u}s)"/><ellipse cx="29" cy="19.4" rx="5.4" ry="2.4" fill="#fff" opacity=".13"/>`;
 o+=avP(`M${32-rx+1.4} 36.4Q32 ${28+ry+3} ${32+rx-1.4} 36.4Q${32+rx-3} ${28+ry-.4} 32 ${28+ry}Q${32-rx+3} ${28+ry-.4} ${32-rx+1.4} 36.4z`,kd,' opacity=".18"');
 o+=`<ellipse cx="25" cy="33" rx="3" ry="2" fill="#f0766a" opacity=".28"/><ellipse cx="39" cy="33" rx="3" ry="2" fill="#f0766a" opacity=".28"/>`+EXTRA[c.ex](k,kd);
 o+=NOSE[c.no](k,kd)+EYES[c.ey](k,ic);
 const bcol=hcol==='#efe3c0'||hcol==='#e9e9e6'?'#b8ad90':hcol==='#a9a9a6'?'#8e8e88':hd;
 o+=BROW[c.eb](bcol)+FHAIR[c.fh](hd)+MOUTH[c.mo]()+GLASS[c.gl]();
 o+=hf;
 if(hat>0)o+=HATS[hat](hcl,hcl2);
 return o+'</g></svg>'}
const AV=i=>AVC(typeof i==='object'?i:AVP[i||0]);
let cur=+localStorage.getItem('fd_theme')||0,rf=-1;if(!TL[cur])cur=0;
function setTh(i){cur=i;const t=TL[i],h=t.h,r=document.documentElement.style,v=(k,x)=>r.setProperty(k,x);
const hh=Math.round(85+(h%60)),sk=Math.round(190+(h%36)),ac=Math.round(18+(h%30)),P=(a,s,l)=>`hsl(${a},${s}%,${l}%)`;v('--sky',P(Math.min(sk,212),80,58));v('--bg',P(hh,40,96));v('--card','#fff');v('--tx',P(hh,35,14));v('--mut',P(hh,12,42));v('--pri',P(hh,50,26));v('--acc',P(ac,80,56));v('--ln',P(hh,30,88));v('--soft',P(hh,45,92));v('--h1',P(sk,70,86));v('--h2',P(hh,45,60));
localStorage.setItem('fd_theme',i);$('thn').textContent='ธีมตอนนี้: '+t.n+' · '+t.p;$('spS').innerHTML=S(h,t.m,1,t.n);$('hhS').innerHTML=S(h,t.m,1,t.n);$('hpn').textContent=t.n;$('auS').innerHTML=S(h,t.m,1,t.n);$('afS').innerHTML=S(h,t.m,1,t.n);homeR()}
function homeR(){const q=$('hq').value.trim();$('hc').innerHTML=['ทั้งหมด',...RG].map((n,i)=>`<button class="chip${i-1===rf?' a':''}" data-r="${i-1}" style="flex:none">${n==='ทั้งหมด'?n:'ภาค'+n}</button>`).join('');
 $('hl').innerHTML=RG.map((g,ri)=>{if(rf>=0&&rf!==ri)return'';const L=TL.map((t,i)=>({...t,i})).filter(t=>t.r===ri&&(!q||(t.n+t.p).includes(q)));if(!L.length)return'';
 return `<div class="rh">ภาค${g}</div><div class="pg">`+L.map(t=>`<div class="pc" style="--soft:hsl(${t.h},55%,93%)"><div class="ar"><svg viewBox="0 0 200 170">${S(t.h,t.m,0,t.n)}</svg></div><b>${t.n}</b><span class="sm"><svg class="pn" viewBox="0 0 24 24"><path d="M12 21s7-6.2 7-11a7 7 0 0 0-14 0c0 4.8 7 11 7 11z"/><circle cx="12" cy="10" r="2.5"/></svg> ${t.p}</span><button class="ob" data-i="${t.i}">${t.i===cur?'✓ ใช้อยู่':'ใช้ธีมนี้'}</button></div>`).join('')+'</div>'}).join('')}
$('hc').onclick=e=>{const b=e.target.closest('[data-r]');if(b){rf=+b.dataset.r;homeR()}};
$('hl').onclick=e=>{const b=e.target.closest('[data-i]');if(b)setTh(+b.dataset.i)};$('hq').oninput=homeR;
$('thg').onclick=()=>$('t4').click();avRefresh();$('av').onclick=()=>$('t3').click();
document.documentElement.dataset.theme='light';setTh(cur);
const sA=f=>{const a=AC();if(!a[U])return;f(a[U]);AW(a);PF=a[U].pf||{}};
function bmi(){const h=+$('pfh').value/100,w=+$('pfw').value;$('pfb').textContent=h&&w?'BMI '+(w/h/h).toFixed(1)+' (ค่าอ้างอิงทั่วไป ไม่ใช่คำแนะนำทางการแพทย์)':''}
const AG=[
{n:'ร่างกาย',g:[{k:'sk',l:'สีผิว',c:1},{k:'fs',l:'รูปหน้า',vb:'8 2 48 48'},{k:'ex',l:'ลายบนหน้า / ทานาคา',vb:'14 12 36 36'},{k:'po',l:'ท่าทาง',vb:'0 14 64 50'}]},
{n:'ผม',g:[{k:'hs',l:'ทรงผม',vb:'6 0 52 52'},{k:'hc',l:'สีผม',c:1}]},
{n:'ใบหน้า',g:[{k:'ey',l:'ทรงตา',vb:'14 14 36 30'},{k:'ic',l:'สีตา',c:1},{k:'eb',l:'คิ้ว',vb:'14 14 36 30'},{k:'no',l:'จมูก',vb:'18 20 28 26'},{k:'mo',l:'ปาก',vb:'16 22 32 26'},{k:'fh',l:'หนวดเครา',vb:'12 14 40 36'}]},
{n:'เสื้อผ้า',g:[{k:'ts',l:'ชุด',vb:'6 26 52 38'},{k:'tc',l:'สีชุด',c:1},{k:'tp',l:'ลายผ้า',vb:'6 38 52 26'}]},
{n:'ของแต่งตัว',g:[{k:'ht',l:'หมวก / เครื่องประดับผม',vb:'8 0 48 44'},{k:'hl',l:'สีหมวก',c:1,pal:'tc'},{k:'gl',l:'แว่นตา',vb:'14 14 36 30'},{k:'er',l:'ต่างหู',vb:'10 20 44 34'},{k:'nk',l:'สร้อย / พวงมาลัย',vb:'14 30 36 30'}]},
{n:'พื้นหลัง',g:[{k:'bg',l:'สีพื้นหลัง',c:1},{k:'bp',l:'ลายพื้นหลัง',vb:'0 0 64 64'}]}];
const AVTOT=Object.values(AVN).reduce((a,b)=>a+b,0)+Object.values(AVD).reduce((a,b)=>a+b.length,0);
let avSec=0;
function avCfg(){return Object.assign({},AVDEF,PF.ava||AVP[PF.av||0])}
function avRand(){const r=n=>Math.random()*n|0,c={};for(const k in AVN)c[k]=r(AVN[k]);c.sk=r(12);c.hc=r(16);c.ic=r(8);c.tc=r(16);c.hl=r(16);c.bg=r(18);
 [['ht',.6],['gl',.6],['fh',.65],['er',.5],['nk',.55],['ex',.5],['po',.6],['tp',.55],['bp',.4]].forEach(a=>{if(Math.random()<a[1])c[a[0]]=0});return c}
function avRefresh(){const c=avCfg(),s=AVC(c);$('av').innerHTML=s;$('hav').innerHTML=s}
function avs(){const c=avCfg(),G=AG[avSec];
 $('ast').innerHTML=AG.map((g,i)=>`<button class="chip${i===avSec?' a':''}" data-sec="${i}">${i+1}. ${g.n} <small>${g.g.length}</small></button>`).join('');
 $('avpr').innerHTML=AVP.map((_,i)=>`<button class="pr" data-pr="${i}" aria-label="แบบสำเร็จรูป ${i+1}">${AVC(Object.assign({},AVDEF,AVP[i]))}</button>`).join('');
 $('ag').innerHTML=G.g.map(g=>`<div class="gl">${g.l}</div>`+(g.c?`<div class="aw">${AVD[g.pal||g.k].map((col,i)=>`<button data-k="${g.k}" data-v="${i}" class="${c[g.k]===i?'on':''}" style="background:${col}" aria-label="${g.l} ${i+1}"></button>`).join('')}</div>`:`<div class="ao">${[...Array(AVN[g.k])].map((_,i)=>`<button data-k="${g.k}" data-v="${i}" class="${c[g.k]===i?'on':''}" aria-label="${g.l} ${i+1}">${AVC(Object.assign({},c,{[g.k]:i}),g.vb)}</button>`).join('')}</div>`)).join('');
 $('ag').innerHTML+=`<button class="chip nx" data-sec="${(avSec+1)%AG.length}">ถัดไป: ${AG[(avSec+1)%AG.length].n} ›</button>`;$('avp').innerHTML=AVC(c);$('avn').textContent='ตัวเลือก '+AVTOT+' แบบ จับคู่ได้นับล้านลุค'}
$('avc').onclick=e=>{const t=e.target.closest('[data-sec],[data-pr],[data-k],#avr,#avz');if(!t)return;
 if(t.dataset.sec!==undefined){avSec=+t.dataset.sec;avs();return}
 let c=avCfg();
 if(t.dataset.pr!==undefined)c=Object.assign({},AVDEF,AVP[+t.dataset.pr]);
 else if(t.id==='avr')c=avRand();else if(t.id==='avz')c=Object.assign({},AVDEF,AVP[0]);
 else c[t.dataset.k]=+t.dataset.v;
 sA(o=>{o.pf=Object.assign(o.pf||{},{ava:c})});avRefresh();avs()};
if(ME){$('pfn').value=ME.n;$('pfa').value=PF.age||'';$('pfh').value=PF.ht||'';$('pfw').value=PF.wt||'';$('pfg').value=PF.goal||'';bmi();avs()}

$('pfh').oninput=$('pfw').oninput=bmi;
$('pfs').onclick=()=>{const n=$('pfn').value.trim();if(!n){$('pfm').textContent='กรอกชื่อที่ให้เรียกก่อน';return}
 sA(o=>{o.n=n;o.pf=Object.assign(o.pf||{},{age:$('pfa').value,ht:$('pfh').value,wt:$('pfw').value,goal:$('pfg').value})});
 $('hn').textContent=n;$('pfm').textContent='บันทึกแล้ว'};
$('cps').onclick=async()=>{const a=AC(),o=a[U],e=$('cpm');if(!o)return;if(!(await pwOk(o,$('cp0').value))){e.textContent='รหัสผ่านเดิมไม่ถูกต้อง';return}
 if($('cp1').value.length<4){e.textContent='รหัสผ่านใหม่อย่างน้อย 4 ตัว';return}o.h=await H($('cp1').value);AW(a);$('cp0').value=$('cp1').value='';e.textContent='เปลี่ยนรหัสผ่านแล้ว'};
