# ThaiFlex

เว็บแอปเดียวจบ (HTML ไฟล์เดียว) — ใช้งานผ่านเบราว์เซอร์ได้เลย ข้อมูลเก็บในเครื่องผู้ใช้ (localStorage)

## วิธีขึ้น GitHub Pages
1. สร้าง repo ใหม่ใน GitHub (เช่น `thaiflex`)
2. อัปโหลดไฟล์ทั้งหมดในโฟลเดอร์นี้ขึ้นไปที่ root ของ repo
3. ไปที่ **Settings → Pages → Build and deployment**
4. Source: **Deploy from a branch** → Branch: `main` / `/ (root)` → Save
5. รอ 1–2 นาที เว็บจะอยู่ที่ `https://<ชื่อผู้ใช้>.github.io/thaiflex/`

## ไฟล์ในโปรเจกต์
- `index.html` – โครงหน้าเว็บ (HTML)
- `css/style.css` – สไตล์ทั้งหมด
- `js/data.js` – ฐานข้อมูลอาหารและเมนูสำเร็จรูป
- `js/core.js` – state, คำนวณสารอาหาร, บันทึกการกิน
- `js/art.js` – ภาพประกอบ/ฉาก SVG, ไอคอน, โลโก้
- `js/avatar.js` – โปรไฟล์และระบบสร้างอวาตาร์
- `js/app.js` – บัญชีผู้ใช้, ธีม, หน้าแรก, ประวัติ, เริ่มต้นแอป

> ลำดับการโหลดสคริปต์ใน `index.html` สำคัญ ห้ามสลับ: data → core → art → avatar → app
- `manifest.webmanifest`, `icons/` – ติดตั้งลงหน้าจอโฮมได้ (PWA)
- `sw.js` – แคชให้เปิดแบบออฟไลน์ได้
- `.nojekyll` – บอก GitHub Pages ไม่ต้องประมวลผลด้วย Jekyll

## หมายเหตุ
- ฟอนต์โหลดจาก Google Fonts (ออฟไลน์จะใช้ฟอนต์สำรองของเครื่อง)
- หากแก้ไฟล์ แล้วอยากให้ผู้ใช้เห็นเวอร์ชันใหม่ทันที ให้เปลี่ยนเลข `CACHE` ใน `sw.js`
